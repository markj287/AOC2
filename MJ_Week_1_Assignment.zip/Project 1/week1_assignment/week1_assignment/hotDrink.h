//
//  hotDrink.h
//  week1_assignment
//
//  Created by Mark Johnson on 11/2/13.
//  Copyright (c) 2013 Mark Johnson. All rights reserved.
//

#import "drinksRecipe.h"

@interface hotDrink : drinksRecipe

@property int minToBoil;
@property int amountOfCream;
@property bool sugar;


@end
