//
//  coldDrink.h
//  week1_assignment
//
//  Created by Mark Johnson on 11/2/13.
//  Copyright (c) 2013 Mark Johnson. All rights reserved.
//

#import "drinksRecipe.h"

@interface coldDrink : drinksRecipe

// Unique data members for cold drink
@property int ice;
@property int scoopsOfSugar;

@end
