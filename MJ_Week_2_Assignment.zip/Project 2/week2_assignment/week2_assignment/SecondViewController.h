//
//  SecondViewController.h
//  week2_assignment
//
//  Created by Mark Johnson on 11/8/13.
//  Copyright (c) 2013 Mark Johnson. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

-(IBAction)onClose:(id)sender;

@end
