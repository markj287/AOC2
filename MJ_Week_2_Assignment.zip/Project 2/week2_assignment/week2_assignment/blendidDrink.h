//
//  blendidDrink.h
//  week2_assignment
//
//  Created by Mark Johnson on 11/7/13.
//  Copyright (c) 2013 Mark Johnson. All rights reserved.
//

#import "drinksRecipe.h"

@interface blendidDrink : drinksRecipe

@property int blendTime;
@property int ice;
@property bool willUseFruit;

@end
