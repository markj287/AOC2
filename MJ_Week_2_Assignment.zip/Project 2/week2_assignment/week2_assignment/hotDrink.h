//
//  hotDrink.h
//  week2_assignment
//
//  Created by Mark Johnson on 11/7/13.
//  Copyright (c) 2013 Mark Johnson. All rights reserved.
//

#import "drinksRecipe.h"

@interface hotDrink : drinksRecipe

@property int minToBoil;
@property int amountOfCream;
@property bool sugar;

@end
